ALTER TABLE `#__extensions` ADD namespace VARCHAR(500) NOT NULL DEFAULT '' AFTER params;
