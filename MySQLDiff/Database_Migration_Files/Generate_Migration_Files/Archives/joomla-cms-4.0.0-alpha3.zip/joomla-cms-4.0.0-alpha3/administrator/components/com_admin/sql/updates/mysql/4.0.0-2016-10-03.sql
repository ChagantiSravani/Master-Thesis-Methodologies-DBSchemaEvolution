DELETE FROM `#__extensions` WHERE `name` = 'mod_submenu';
