ALTER TABLE "#__extensions" DROP COLUMN "custom_data";
ALTER TABLE "#__extensions" DROP COLUMN "system_data";
