<html>
<head>
<!-- \$Revision: 1.5 $ -->
    <title>Failed Login</title>
    <meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
    <link rel="stylesheet" href="css/default/login.css" type="text/css">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
    <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td>
            <center><font size='4' color='red'><br /><br /><br /><b>

		Too many failed login attempts<font>
		<P>You will have to see an authorised person to obtain access to the system</b></p></center>
            </td>
        </tr>
    </table>
</body>
</html>
